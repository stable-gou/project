- 用户登录注册案例

 需求说明：

1. 完成用户登录功能，如果用户勾选“记住用户” ，则下次访问登录页面自动填充用户名密码

2. 完成注册功能，并实现验证码功能

![1629442826981](use.assets/1629442826981.png)

- 用户登录功能

需求:

![1629443152010](use.assets/1629443152010.png)

* 用户登录成功后，跳转到列表页面，并在页面上展示当前登录的用户名称
* 用户登录失败后，跳转回登录页面，并在页面上展示对应的错误信息



- 使用的数据

```mysql
-- 创建用户表
CREATE TABLE tb_user(
	id int primary key auto_increment,
	username varchar(20) unique,
	password varchar(32)
);

-- 添加数据
INSERT INTO tb_user(username,password) values('zhangsan','123'),('lisi','234');

SELECT * FROM tb_user;

```

