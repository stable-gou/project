import java.util.BitSet;

public class WaterMark {

    public static BitSet toBitSet() {  //Ok
        String watermark = Config.WATERMARK;
        String binaryBuf = "";
        for (int i = 0; i < watermark.length(); i++) {
            String binaryString = BinaryUtils.intToWaterMarkBinary(watermark.charAt(i));

            for (int j = 0; j < binaryString.length(); j++) { //Cat bits
                binaryBuf += String.valueOf(binaryString.charAt(j));
            }
        }
        return BinaryUtils.binaryToBitSet(binaryBuf);
    }

    /**
     * bitSet 转成水印字符串(为汉字) (我们默认0000是补上的0好了, 扔掉它们)
     *
     * @return Unicode String
     */
    public static String bitSetToWaterMark(BitSet bitSet) { //Ok
        String watermark_rec = "";

        String binary = BinaryUtils.bitSetToBinary(bitSet);
        int length = binary.length() / Config.WATERMARK_BINARY_BITS;

        for (int i = 0; i < length; i++) {
            String binaryString = binary.substring(
                    i * Config.WATERMARK_BINARY_BITS,
                    (i + 1) * Config.WATERMARK_BINARY_BITS);  //endIndex -- 结束索引（不包括）
            char c = BinstrToChar(binaryString);
//            watermark_rec.append(c);
            watermark_rec += c;
        }
        return CharacterUtils.replaceUnPrintable(watermark_rec);
    }

    /**
     * 将二进制字符串转换为char
     */
    private static char BinstrToChar(String binStr) {
        return (char) Integer.parseUnsignedInt(binStr, 2);
    }
}
