import org.apache.commons.codec.DecoderException;
import org.apache.commons.codec.binary.Hex;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.BitSet;


public class Encrypt {

    public static void main(String[] args) {

        String chinese = readChinese(Config.FILENAME);

        KanjiCount kanjiCount = new KanjiCount(chinese, Config.MOST_NUM);

        BitSet kanji = kanjiCount.toBitSet();
        BitSet watermark = WaterMark.toBitSet();
        BitSet logistic = Logistic.toBitSet();

        String encrypted = encrypt(kanji, watermark, logistic);
        boolean checkResult = check(encrypted, Config.WATERMARK, kanji, logistic);
        System.out.println("check result: " + checkResult);
    }

    /**
     * 加密程序
     *
     * @param kanji     BitSet 表示的汉字流
     * @param watermark BitSet 表示的水印流
     * @param logistic  BitSet 表示的logistic流
     * @return 十六进制加密字串
     */
    private static String encrypt(BitSet kanji, BitSet watermark, BitSet logistic) {
        BitSet encryptedWaterMark = (BitSet) watermark.clone();
        encryptedWaterMark.xor(logistic);
        encryptedWaterMark.xor(kanji);

        byte[] byteEncrypted = encryptedWaterMark.toByteArray();
        String hex = Hex.encodeHexString(byteEncrypted);
        System.out.println("encryptedWaterMark to Hex: " + hex);

        return hex;
    }

    /**
     * check whether the register code is ok
     *
     * @param kanji     BitSet 表示的汉字流
     * @param encrypted BitSet 表示的加密信息流
     * @param logistic  表示的logistic流
     * @return 检查结果
     */
    private static boolean check(String encrypted, String watermark, BitSet kanji, BitSet logistic) {
        boolean flag = false;
        try {
            byte[] decodeEncrypted = Hex.decodeHex(encrypted);
            BitSet decodeBitSet = BitSet.valueOf(decodeEncrypted);
            decodeBitSet.xor(logistic);
            decodeBitSet.xor(kanji);
            String decodeWaterMark = WaterMark.bitSetToWaterMark(decodeBitSet);
            System.out.println("original watermark: " + watermark);
            System.out.println("decode watermark: " + decodeWaterMark);

            flag = watermark.equals(decodeWaterMark);
        } catch (DecoderException e) {
            e.getStackTrace();
        }
        return flag;
    }

    private static String readChinese(String filename) {

        Path path = Paths.get(filename);
        String chinese = "";
        try {
            byte[] data = Files.readAllBytes(path);
            String read = new String(data, StandardCharsets.UTF_8); // 指定编码，可以避免乱码。
            chinese = CharacterUtils.getChinese(read);
        } catch (IOException e) {
            e.getStackTrace();
        }
        return chinese;
    }
}




