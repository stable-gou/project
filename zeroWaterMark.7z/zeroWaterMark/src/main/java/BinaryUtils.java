import java.util.BitSet;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class BinaryUtils {

    /*
      Integer.toBinaryString() 方法结果是int到char的转化, 因此 binaryString 里面是 '1' '0'
      toBinaryString() 方法返回由二进制参数(基数为 2)表示的无符号整数值的字符串表示形式。
     */

    /**
     * 二进制转BitSet
     * BitSet.size() 只显示非0的空间占用, 其实正常
     *
     * @param binary 二进制字符串(1 0), 里面是字符, 同时带有空字符'\0'
     * @return bitSet
     */
    public static BitSet binaryToBitSet(String binary) { //Ok
        BitSet bitSet = new BitSet(binary.length());
        for (int i = 0; i < binary.length(); i++) {
            char c = binary.charAt(i);
            bitSet.set(i, c == '1');
        }
        for (int i = 0; i < bitSet.size(); i++) {
            boolean c = bitSet.get(i);
//            System.out.print(c ? "1" : "0"); //TestOnly
        }
//        System.out.println(); //TestOnly
        return bitSet;
    }

    /**
     * 二进制转BitSet
     * BitSet.size() 只显示非0的空间占用, 其实正常
     *
     * @param bitSet bitSet
     * @return binary 二进制字符串(1 0), 里面是字符, 同时带有空字符'\0'
     */
    public static String bitSetToBinary(BitSet bitSet) { //Ok
//        StringBuilder binary = new StringBuilder(Config.FINAL_BITS);
        String binary = "";
        for (int i = 0; i < Config.FINAL_BITS; i++) {
//            binary.append(bitSet.get(i) ? '1' : '0');
            binary += bitSet.get(i) ? "1" : "0";
        }
//        return binary.toString();
        return binary;
    }

    /**
     * 二进制转BitSet (按照我自己的方式解释) 4,4,4,4...
     * BitSet.size() 只显示非0的空间占用, 其实正常
     * @param bitSet bitSet
     * @return binary 二进制字符串(1 0), 里面是字符, 同时带有空字符'\0'
     */
//    public static String bitSetToHexString(BitSet bitSet) { //Ok
////        StringBuilder binary = new StringBuilder(Config.FINAL_BITS);
//        String binary = "";
//        for (int i = 0; i < bitSet.; i++) {
////            binary.append(bitSet.get(i) ? '1' : '0');
//            binary += bitSet.get(i) ? "1" : "0";
//        }
////        return binary.toString();
//        return  binary;
//    }

    /**
     * 取低 KANJI_STROKE_BINARY_BITS 位的二进制字符串
     *
     * @param num 数字
     * @return 取低 KANJI_STROKE_BINARY_BITS 位的二进制字符串
     */
    public static String intToStrokeBinary(int num) {
        //补零
        String binaryStr = Integer.toBinaryString(num);
        int bitNum = Config.KANJI_STROKE_BINARY_BITS;
        if (bitNum < binaryStr.length()) {
            bitNum += bitNum;//不断翻倍8 16 32 64...
        }
        while (binaryStr.length() < bitNum) {
            binaryStr = "0" + binaryStr;
        }
        return binaryStr.substring(0, Config.KANJI_STROKE_BINARY_BITS);
    }

    public static String intToWaterMarkBinary(char unicodeChar) { //Ok
        //补零
        String binaryStr = Integer.toBinaryString(unicodeChar);
        int bitNum = Config.WATERMARK_BINARY_BITS;
        if (bitNum < binaryStr.length()) {
            bitNum += bitNum;//不断翻倍8 16 32 64...
        }
        while (binaryStr.length() < bitNum) {
            binaryStr = "0" + binaryStr;
        }
        return binaryStr.substring(0, Config.WATERMARK_BINARY_BITS);
    }
}


class CharacterUtils {

    public static String getChinese(String paramValue) { //Ok
        String regex = "([\u4e00-\u9fa5]+)";
        StringBuilder str = new StringBuilder();
        Matcher matcher = Pattern.compile(regex).matcher(paramValue);
        while (matcher.find()) {
            str.append(matcher.group(0));
        }
        return str.toString();
    }

    /**
     * 过滤掉String中的不可见UNICODE字符
     *
     * @param source 源字符串
     * @return 过滤掉不可见字符的字符串
     */
    public static String replaceUnPrintable(String source) { //Ok
        final String REGREX = "[\\u200b-\\u200f]|[\\u200e-\\u200f]|[\\u202a-\\u202e]|[\\u2066-\\u2069]|\ufeff|\u06ec|\u0000";
        Pattern compile = Pattern.compile(REGREX);
        Matcher matcher = compile.matcher(source);
        if (matcher.find()) {
            return matcher.replaceAll("");
        }
        return source;
    }
}