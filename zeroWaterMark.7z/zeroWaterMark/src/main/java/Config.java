public class Config {
    public static final int MOST_NUM = 20;
    public static final String FILENAME = "origin.txt";
    public static final String WATERMARK = "必须是Unicode可打印字符"; //必须是Unicode可打印字符
    public static final int PASSWORD = Integer.parseUnsignedInt("01234567", 10); //password是八位的密码
    public static int KANJI_STROKE_BINARY_BITS = 5;
    public static int WATERMARK_BINARY_BITS = 16;
    public static final int FINAL_BITS = getBits(); //这里要考虑bit对齐的约定问题

    private static int getBits() {
        int kanji_bits = KANJI_STROKE_BINARY_BITS * MOST_NUM;
        int watermark_bits = WATERMARK_BINARY_BITS * WATERMARK.length();
        return Math.max(kanji_bits, watermark_bits);
    }
}