import java.util.BitSet;

public class Logistic {
    public static BitSet toBitSet() {
        int length = Config.FINAL_BITS;
        int password = Config.PASSWORD;

        float[] x = new float[length];

        float u = 4f;
        password %= 100000000;

        x[0] = (password % 10000) * 0.0001f; //1~4
        //迭代500次达到有效的混沌
        for (int c = 0; c < 500; c++) {
            for (int i = 0; i < length - 1; i++) {
                x[i + 1] = u * x[i] * (1 - x[i]);
            }
        }

        float delta = 0.5f;
        String binary = "";
        //二进制处理得到二值序列
        for (int i = 0; i < length; i++) {
            binary += (x[i] > delta) ? "1" : "0";
        }
        return BinaryUtils.binaryToBitSet(binary);
    }
}
